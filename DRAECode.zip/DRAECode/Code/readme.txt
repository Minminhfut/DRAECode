
The codes of the DRAE algorithm of the paper titled with "Dual-representation-based autoencoder for domain adaptation"。

Yang S, Yu K, Cao F, et al. "Dual-representation-based autoencoder for domain adaptation[J]. IEEE Transactions on Cybernetics, 2020.




















