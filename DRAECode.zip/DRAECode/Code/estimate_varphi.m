function [dist] = estimate_varphi(Xs,Xt)
    Yss = ones(size(Xs,2),1);
    Ytt = ones(size(Xt,2),1) * 2;
    [acc,~] = Pseudolable([Xs,Xt], [Xs,Xt], [Yss;Ytt], [Yss;Ytt])
    dist = 1 + 2 * (1 - acc / 100);
end