function [acc] = DRAE(src_X,src_labels,tar_X,tar_labels,parameter)

%     tuning parameters 
%     parameter.lambda 
%     parameter.beta 
%     parameter.noises 
%     parameter.theda 
%     parameter.gamma 
%     parameter.k 
        
    [src_X,src_labels] = Data_Sort(src_X,src_labels);
    [tar_X,tar_labels] = Data_Sort(tar_X,tar_labels);
    [~,Y_tar_pseudo] = Pseudolable(src_X, tar_X, src_labels, tar_labels);
  
    Num_Class = length(unique(src_labels));
    lables = unique(src_labels);
    
    layers = parameter.layers;
    for iter = 1 : layers
        parameter.layers = iter;
        
        % CD-MDA
        total = [src_X,tar_X];
        nbsrc = size(src_X,2);
        nbtgt = size(tar_X,2);
     
        % Computer Mc
        disp('Computer Mc...');
        parameter.Mc = C_MMD(src_X, tar_X, src_labels,Y_tar_pseudo); 
        
        % Computer Ms
        disp('Computer Ms...');
        SrcMdist = zeros(size(src_X,2),size(src_X,2));
        for iter_class = 1: Num_Class
            c_one = lables(iter_class);
            class_one = find(src_labels==c_one);
            for iter_class2 = 1: Num_Class
                c_two = lables(iter_class2);
                class_two = find(src_labels==c_two);
                if c_one == c_two
                    SrcMdist(class_one,class_two) = 1/length(find(src_labels==c_one))/length(find(src_labels==c_two));
                else
                    SrcMdist(class_one,class_two) = -1/length(find(src_labels==c_one))/length(find(src_labels==c_two));
                end  
            end
        end
        parameter.Ms = SrcMdist / norm(SrcMdist,'fro');

        % Computer Mt
        disp('Computer Mt...');
        TarMdist = zeros(size(tar_X,2),size(tar_X,2));
        for iter_class = 1: Num_Class
            c_one = lables(iter_class);
            class_one = find(Y_tar_pseudo==c_one);
            for iter_class2 = 1: Num_Class
                c_two = lables(iter_class2);
                class_two = find(Y_tar_pseudo==c_two);
                if c_one == c_two
                    TarMdist(class_one,class_two) = 1/length(find(Y_tar_pseudo==c_one))/length(find(Y_tar_pseudo==c_two));
                else
                    TarMdist(class_one,class_two) = -1/length(find(Y_tar_pseudo==c_one))/length(find(Y_tar_pseudo==c_two));
                end  
            end
        end
        parameter.Mt = TarMdist / norm(TarMdist,'fro');
       
        parameter.size = size(src_X,2);
        [global_allhx, ~] = StackCD_MDA(double(total>0), parameter);
%         [global_allhx, ~] = StackCD_MDA(total, parameter);
     
	
		% MM-MDA
        local_src_X = zeros(parameter.layers*size(src_X,1),size(src_X,2));
        local_tar_X = zeros(parameter.layers*size(src_X,1),size(tar_X,2));
%         local_src_X = [];
%         local_tar_X = [];
        for iter_class = 1: Num_Class
            Xs_c = src_X(:,find(src_labels==lables(iter_class)));
            Xt_c = tar_X(:,find(Y_tar_pseudo==lables(iter_class)));
            total  = [Xs_c,Xt_c];

            nbsrc=size(Xs_c,2);
            nbtgt=size(Xt_c,2);
            parameter.size = size(Xs_c,2);
            parameter.M0=[(1/nbsrc^2)*ones(nbsrc,nbsrc), -1/(nbsrc*nbtgt)*ones(nbsrc,nbtgt);...
                -1/(nbsrc*nbtgt)*ones(nbtgt,nbsrc), (1/nbtgt^2)*ones(nbtgt,nbtgt)];
            [allhx_local, ~] = StackMM_MDA(total, parameter);
            local_src_X(:,find(src_labels==lables(iter_class))) = allhx_local(:,1:size(Xs_c,2));
            local_tar_X(:,find(Y_tar_pseudo==lables(iter_class))) =  allhx_local(:,1+size(Xs_c,2):end);
%             local_src_X = [local_src_X,allhx_local(:,1:size(Xs_c,2))];
%             local_tar_X = [local_tar_X,allhx_local(:,1+size(Xs_c,2):end)]; %not accurate, the order of the target samples may change
        end
		
        
        local_allhx = [local_src_X,local_tar_X];
        if iter == layers
            XsGlocal = global_allhx(:,1:size(src_X,2));
            XtGlocal = global_allhx(:,size(src_X,2)+1:end);
            XsLocal = local_allhx(:,1:size(src_X,2));
            XtLocal = local_allhx(:,size(src_X,2)+1:end);
            distg = estimate_varphi(XsGlocal,XtGlocal);
            distl = estimate_varphi(XsLocal,XtLocal);
    
            varphi_g = distg / (distg+distl);
            varphi_l = 1 - varphi_g;
    
            [acc_g,~] = Pseudolable(XsGlocal, XsGlocal, src_labels, src_labels);
            [acc_l,~] = Pseudolable(XsLocal, XsLocal, src_labels, src_labels);
            
            preg = acc_g / 100;
            prel = acc_l / 100;
    
            eta_g = preg / (preg + prel);
            eta_l = 1 - eta_g;
            wg = 2 * varphi_g * eta_g / (varphi_g + eta_g);
            wl = 2 * varphi_l * eta_l / (varphi_l + eta_l);
            mu = wg / (wg + wl);
            dual_allhx = [mu*global_allhx;(1-mu)*local_allhx];
        else
            dual_allhx = [global_allhx;local_allhx];
        end
     
        xr = dual_allhx(:,1:size(src_X,2));
        xe = dual_allhx(:,size(src_X,2)+1:end);

        xr=xr';
        bestC = 1./mean(sum(xr.*xr,2));
        model = svmtrain(src_labels,xr,['-q -t 0 -c ',num2str(bestC),' -m 3000']);
        xe=xe';
        [Y_tar_pseudo,accuracy] = svmpredict(tar_labels,xe,model);
        if iter ==layers
            acc = accuracy(1);
        end
    end
end
















