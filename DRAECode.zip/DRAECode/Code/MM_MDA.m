function [hx, W] = MM_MDA(xx,parameter)
    % xx : dxn input
    [d, n] = size(xx);
    % adding bias
    xxb = [xx; ones(1, n)];

    % scatter matrix S
    S = xxb*xxb';

    % corruption vector
    q = ones(d+1, 1)*(1-parameter.noises);
    q(end) = 1;


    % Q: (d+1)x(d+1)
    Q = S.*(q*q');
    Q(1:d+2:end) = q.*diag(S);

    % P: dx(d+1)
    P = S(1:end-1,:).*repmat(q', d, 1);

    U_21 = xxb*parameter.M0*xxb';
    U_21 = U_21.*(q*q');
    U_21(1:d+2:end) = q.*diag(U_21);
 
    L = LaplacianMatrix(xx(:,1:parameter.size),xx(:,1+parameter.size:end),parameter.k);
    U_22 = xxb*L*xxb';
    U_22 = U_22.*(q*q');
    U_22(1:d+2:end) = q.*diag(U_22);

    % final W = P*Q^-1, dx(d+1);
    reg = parameter.lambda*eye(d+1);
    reg(end,end) = 0;
    W = P/(Q+reg +parameter.beta*U_21 + parameter.gamma*U_22);
    hx = W*xxb;
    hx = tanh(hx);
end


