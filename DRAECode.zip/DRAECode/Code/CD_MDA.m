function [hx, W] = CD_MDA(xx,parameter)
    % xx : dxn input
    [d, n] = size(xx);
    % adding bias
    xxb = [xx; ones(1, n)];

    % scatter matrix S
    S = xxb*xxb';

    % corruption vector
    q = ones(d+1, 1)*(1-parameter.noises);
    q(end) = 1;

    % Q: (d+1)x(d+1)
    Q = S.*(q*q');
    Q(1:d+2:end) = q.*diag(S);

    % P: dx(d+1)
    P = S(1:end-1,:).*repmat(q', d, 1);

    U_2 = xxb*parameter.Mc*xxb';
    U_2 = U_2.*(q*q');
    U_2(1:d+2:end) = q.*diag(U_2);
    % [a,b]=size(xxb)
    data = xxb(:,1:parameter.size);
    U_3 = data*parameter.Ms*data';
    U_3 = U_3.*(q*q');
    U_3(1:d+2:end) = q.*diag(U_3);

    data = xxb(:,1+parameter.size:end);
    U_4 = data*parameter.Mt*data';
    U_4 = U_4.*(q*q');
    U_4(1:d+2:end) = q.*diag(U_4);

    % final W = P*Q^-1, dx(d+1);
    reg = parameter.lambda*eye(d+1);
    reg(end,end) = 0;
    W = P/(Q+reg +parameter.beta*U_2-parameter.theda*U_3-parameter.theda*U_4);
    hx = W*xxb;
    hx = tanh(hx);
end
