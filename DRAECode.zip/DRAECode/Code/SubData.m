function [X] = SubData (src_X,src_labels,label,local_X,allhx_local)
    index = find(src_labels==label);
    X = [];
    for i=1:size(index,1)
        X = [X,src_X(:,index(i))];
    end
end